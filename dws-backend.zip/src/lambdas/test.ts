import Axios, { AxiosResponse, AxiosError } from "axios"
import { APIGatewayEvent, APIGatewayProxyResult } from "aws-lambda"
import { lambdaResponse } from "./helper"

// interface CreateAppProps {
//     name: string;
// }

// const requestConfig = (token: string) => ({
//     headers: { 
//         'Accept': 'application/vnd.github.baptiste-preview+json' 
//     }
// })

export const createRepo = async (event: APIGatewayEvent): Promise<APIGatewayProxyResult> => {
    //const props = JSON.parse(event.body) as CreateAppProps
    
    try {
        // const response = await Axios.post(process.env.GITHUB_API_URL, {
        //     browser_application: { name: props.name }
        // }, requestConfig(props.pat)) as AxiosResponse<NewrelicCreateAppResponse>
        return lambdaResponse(200, { message: 'heya' })
    
    } catch(e) {
        const { response: { status, data } } = e as AxiosError
        console.log(`Received error attempting to create Git Hub repo`, data)
        return lambdaResponse(status, { message: `Unexpected error occurred with status code ${status}` })
    }
}
